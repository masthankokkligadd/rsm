const productGrid = document.getElementById("productGrid");
const statusMessage = document.getElementById("statusMessage");
const categoryFilter = document.getElementById("categoryFilter");
const searchInput = document.getElementById("searchInput");
const cartPanel = document.getElementById("cartPanel");
const overlay = document.getElementById("overlay");

let products = [];
let cart = [];

const money = value => new Intl.NumberFormat("en-IN", {
  style: "currency", currency: "INR", maximumFractionDigits: 2
}).format(value);

// Read product information from the external XML file.
async function loadProducts() {
  try {
    const response = await fetch("products.xml");
    if (!response.ok) throw new Error("Could not load products.xml");
    const xmlText = await response.text();
    const xml = new DOMParser().parseFromString(xmlText, "application/xml");
    if (xml.querySelector("parsererror")) throw new Error("Invalid XML format");

    products = [...xml.querySelectorAll("product")].map(item => ({
      id: item.querySelector("id")?.textContent || item.getAttribute("id"),
      name: item.querySelector("name").textContent,
      category: item.querySelector("category").textContent,
      price: Number(item.querySelector("price").textContent),
      emoji: item.querySelector("emoji").textContent,
      description: item.querySelector("description").textContent
    }));

    const categories = [...new Set(products.map(p => p.category))];
    categories.forEach(category => {
      const option = document.createElement("option");
      option.value = category;
      option.textContent = category;
      categoryFilter.appendChild(option);
    });
    statusMessage.textContent = `${products.length} products available`;
    renderProducts();
  } catch (error) {
    statusMessage.textContent = "Unable to load products. Run this project with VS Code Live Server.";
    console.error(error);
  }
}

function renderProducts() {
  const selectedCategory = categoryFilter.value;
  const searchTerm = searchInput.value.trim().toLowerCase();
  const filtered = products.filter(product =>
    (selectedCategory === "all" || product.category === selectedCategory) &&
    (product.name.toLowerCase().includes(searchTerm) ||
     product.category.toLowerCase().includes(searchTerm))
  );

  productGrid.innerHTML = "";
  if (!filtered.length) {
    productGrid.innerHTML = '<p class="status">No products found. Try another search.</p>';
    return;
  }

  filtered.forEach(product => {
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <div class="product-image" aria-hidden="true">${product.emoji}</div>
      <span class="category">${product.category}</span>
      <h3>${escapeHTML(product.name)}</h3>
      <span class="category">${escapeHTML(product.description)}</span>
      <div class="product-bottom">
        <span class="price">${money(product.price)}</span>
        <button class="add-button" data-id="${product.id}">Add to cart</button>
      </div>`;
    productGrid.appendChild(card);
  });
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  })[char]);
}

function addToCart(id) {
  const product = products.find(p => String(p.id) === String(id));
  if (!product) return;
  const existing = cart.find(item => String(item.id) === String(id));
  if (existing) existing.quantity += 1;
  else cart.push({ ...product, quantity: 1 });
  renderCart();
}

function changeQuantity(id, amount) {
  const item = cart.find(p => String(p.id) === String(id));
  if (!item) return;
  item.quantity += amount;
  if (item.quantity <= 0) cart = cart.filter(p => String(p.id) !== String(id));
  renderCart();
}

function removeFromCart(id) {
  cart = cart.filter(p => String(p.id) !== String(id));
  renderCart();
}

function renderCart() {
  const cartItems = document.getElementById("cartItems");
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  document.getElementById("cartCount").textContent = count;
  document.getElementById("cartTotal").textContent = money(total);

  if (!cart.length) {
    cartItems.innerHTML = '<p class="empty-cart">Your cart is empty.</p>';
    return;
  }

  cartItems.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-emoji">${item.emoji}</div>
      <div>
        <h4>${escapeHTML(item.name)}</h4>
        <small>${money(item.price)} each</small>
        <div class="quantity">
          <button data-action="decrease" data-id="${item.id}" aria-label="Decrease quantity">−</button>
          <span>${item.quantity}</span>
          <button data-action="increase" data-id="${item.id}" aria-label="Increase quantity">+</button>
        </div>
      </div>
      <button class="remove-button" data-action="remove" data-id="${item.id}">Remove</button>
    </div>`).join("");
}

function openCart() {
  cartPanel.classList.add("open");
  overlay.classList.add("open");
}
function closeCart() {
  cartPanel.classList.remove("open");
  overlay.classList.remove("open");
}

productGrid.addEventListener("click", event => {
  const button = event.target.closest("[data-id]");
  if (button) addToCart(button.dataset.id);
});
document.getElementById("cartItems").addEventListener("click", event => {
  const button = event.target.closest("[data-action]");
  if (!button) return;
  const { action, id } = button.dataset;
  if (action === "increase") changeQuantity(id, 1);
  if (action === "decrease") changeQuantity(id, -1);
  if (action === "remove") removeFromCart(id);
});
categoryFilter.addEventListener("change", renderProducts);
searchInput.addEventListener("input", renderProducts);
document.getElementById("searchButton").addEventListener("click", renderProducts);
document.getElementById("cartToggle").addEventListener("click", openCart);
document.getElementById("closeCart").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);

document.getElementById("checkoutButton").addEventListener("click", () => {
  if (!cart.length) {
    alert("Your cart is empty. Add a product before checkout.");
    return;
  }
  alert(`Order placed successfully!\\nDemo total: ${money(cart.reduce((sum, item) => sum + item.price * item.quantity, 0))}\\nThis is only a project demonstration; no payment was made.`);
  cart = [];
  renderCart();
  closeCart();
});

loadProducts();
