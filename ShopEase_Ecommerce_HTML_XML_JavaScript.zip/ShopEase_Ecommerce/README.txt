SHOPEASE - E-COMMERCE MINI PROJECT
==================================

Technologies:
- HTML: page structure
- CSS: design and responsive layout
- JavaScript: product display, search, category filter and shopping cart
- XML: stores product information in products.xml

FEATURES
--------
1. Displays products read from an XML file.
2. Search products by name or category.
3. Filter products by category.
4. Add products to the shopping cart.
5. Increase/decrease product quantities.
6. Remove products from the cart.
7. Calculates the cart total in Indian Rupees.
8. Demo checkout confirmation.

HOW TO RUN
----------
IMPORTANT: Do not open index.html directly by double-clicking it.
Browsers normally block fetch() from reading local XML files using file://.

Option 1 - Visual Studio Code:
1. Extract the ZIP file.
2. Open the extracted folder in Visual Studio Code.
3. Install the "Live Server" extension if it is not installed.
4. Right-click index.html and choose "Open with Live Server".
5. The store opens in your browser.

Option 2 - Python local server:
1. Open a terminal inside the extracted project folder.
2. Run: python -m http.server 8000
3. Open http://localhost:8000 in your browser.

PROJECT FILES
-------------
index.html   - Main web page
styles.css   - Page styling and responsive layout
app.js       - E-commerce functionality
products.xml - Product data
README.txt   - Project instructions

NOTE
----
This is a front-end educational demo. Checkout is simulated. It does not
include a database, user login, order storage, server or real payment gateway.
